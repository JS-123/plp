package com.sample.stocktrading.client;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface StockPriceServiceAsync {
	
	 void getPrices(String[] symbols, AsyncCallback<StockPrice[]> callback);

	void getAllStocks(AsyncCallback<List<StockPrice>> callback);

	void Save(StockPrice stock, AsyncCallback<String> asyncCallback);

	void delete(StockPrice stock, AsyncCallback<Void> callback);

	
}
