package com.sample.stocktrading.client;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
@RemoteServiceRelativePath("rpc/stockPrice")
public interface StockPriceService extends RemoteService {

	

	StockPrice[] getPrices(String[] symbols);
	List<StockPrice> getAllStocks();
	String Save(StockPrice stock);
	void delete(StockPrice stock);
	
	
   
	
	
}
