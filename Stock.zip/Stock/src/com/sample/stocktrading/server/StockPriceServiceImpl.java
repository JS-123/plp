package com.sample.stocktrading.server;

import java.util.List;

import java.util.Random;


import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sample.stocktrading.client.StockPrice;
import com.sample.stocktrading.client.StockPriceService;
import com.sample.stocktrading.server.StockPriceDao;
import com.sample.stocktrading.server.StockPriceBo;
import com.sample.stocktrading.server.StockPriceDaoImpl;

@SuppressWarnings("serial")
public class StockPriceServiceImpl extends RemoteServiceServlet implements StockPriceService {
	
	 
	StockPriceDao stockdao=null;
	
  public void setStockdao(StockPriceDao stockdao) {
		this.stockdao = stockdao;
	}
  
  
	private static final double MAX_PRICE=100.0;
	private static final double MAX_PRICE_CHANGE=0.02;
	

	@Override
	public StockPrice[] getPrices(String[] symbols) {
		Random rnd=new Random();
		 StockPrice[] prices = new StockPrice[symbols.length];
		    for (int i=0; i<symbols.length; i++) {
		      double price = rnd.nextDouble() * MAX_PRICE;
		      double change = price * MAX_PRICE_CHANGE * (rnd.nextDouble() * 2f - 1f);

		      prices[i] = new StockPrice(symbols[i], price, change);
		    }		
		
		return prices;
	}

	@Override
	public List<StockPrice> getAllStocks() {

		return stockdao.getAllStocks();
	
	}

	@Override
	public String Save(StockPrice stock) {
		return stockdao.Save(stock);
	}

	@Override
	public void delete(StockPrice stock) {
		 stockdao.delete(stock);
		
		
	}
	
   
	
}
