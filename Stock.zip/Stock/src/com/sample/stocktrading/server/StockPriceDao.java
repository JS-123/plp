package com.sample.stocktrading.server;

import java.util.List;

import com.sample.stocktrading.client.StockPrice;


public interface StockPriceDao {
	
	List<StockPrice> getAllStocks();
	String Save(StockPrice  stock);
	//boolean Save(StockPriceBo bo);
	void delete(StockPrice stock);
	

}
