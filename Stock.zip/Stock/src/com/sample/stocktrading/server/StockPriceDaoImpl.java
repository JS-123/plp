package com.sample.stocktrading.server;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.sample.stocktrading.client.StockPrice;


public class StockPriceDaoImpl implements StockPriceDao {
	private HibernateTemplate hibernateTemplate;
	private SessionFactory sessionFactory;

	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public HibernateTemplate getHibernateTemplate() {
	return hibernateTemplate;
}

public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
	this.hibernateTemplate = hibernateTemplate;
}

	@Override
public List<StockPrice> getAllStocks() {
	List<StockPrice> list= hibernateTemplate.loadAll(StockPrice.class);
	return list;
	}

	
@Override
@Transactional
public String Save(StockPrice stock) {
	String res = null;
	try{
		//res = (hibernateTemplate.save(stock)).toString();
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(stock);
		tx.commit();
		session.close();
	}catch(Exception e){
		e.printStackTrace();
	}
	
	return res;
}

@Override
public void delete(StockPrice stock) {
	hibernateTemplate.delete(stock);
	try{
		//res = (hibernateTemplate.save(stock)).toString();
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		//session.persist(stock);
	session.delete(stock);
		tx.commit();
		session.close();
	}catch(Exception e){
		e.printStackTrace();
	}
	

}


public StockPriceDaoImpl() {
	}

	
	
}
