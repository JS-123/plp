package com.example.project;

import com.example.project.client.Stock;
import com.example.project.server.StockTraderServiceImpl;

public class StockTest {

	public static void main(String[] args) {
		
		StockTraderServiceImpl stockimpl=new StockTraderServiceImpl();
		
		Stock stock=new Stock();
		
		stock.setStockId(0);							
		stock.setStockName("reliance");
		stock.setStockPrice(1000);
		
		stock.setQuantity(50);
		//stock.setChange(0);
		stock.setDateOfPurchase("17/08/1997");
		stockimpl.createStock(stock);
		
		
	}

}
