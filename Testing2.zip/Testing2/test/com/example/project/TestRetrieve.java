package com.example.project;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.example.project.client.User;

public class TestRetrieve {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        
        Session session = sessionFactory.getCurrentSession();
         
        try {
            session.beginTransaction();
             
           // for (int i = 0; i < 3; i++) {
                User user = new User();
                user.setUserName("jai");
                user.setPassWord("pass");
                user.setCity("hyd");
                
                session.save(user);
            
             
            session.getTransaction().commit();
        }
        catch (HibernateException e) {
            e.printStackTrace();
            session.getTransaction().rollback();
        }
         
        session = sessionFactory.getCurrentSession();
         
        int id=1 ;
 
        try {
            session.beginTransaction();
             
            Criteria criteria = session.createCriteria(User.class);
            criteria.add(Restrictions.eq("id", id));
             
            User user = (User) criteria.uniqueResult();
             
            if (user!=null) {
                System.out.println("User found:");
                System.out.println(user.getId() + " - " + user.getUserName());
            }
            else
            	System.out.println("user not found!!");
             
            session.getTransaction().commit();
        }
        catch (HibernateException e) {
            e.printStackTrace();
            session.getTransaction().rollback();

	}

	}}
