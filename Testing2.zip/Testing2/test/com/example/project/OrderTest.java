package com.example.project;

import com.example.project.client.Order;
import com.example.project.server.StockTraderServiceImpl;

public class OrderTest {

	public static void main(String[] args) {
		StockTraderServiceImpl stockimpl=new StockTraderServiceImpl();
		Order order=new Order();
		order.setOrderId(0);
		order.setStockName("hcl");
		order.setStockPrice(1000);
		order.setDateOfPurchase("17/08/2019");
		order.setEmailId("hello");
		stockimpl.createOrder(order);
		
		

	}

}
