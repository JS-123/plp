package com.example.project;

import com.example.project.client.User;
import com.example.project.server.StockTraderServiceImpl;

public class MyTest {

	public static void main(String[] args) {
		
		StockTraderServiceImpl stockimpl=new StockTraderServiceImpl();
		User user=new User();
		
		user.setId(0);
		user.setUserName("jazz");
		user.setPhoneNum("766102332");
		user.setCity("hyderabad");
		user.setEmailId("abc@gmail.com");
		user.setDOB("17/08/1997");
		user.setPassWord("hello123");
		int id=stockimpl.createUser(user);
		System.out.println("User created with Id : "+id);
	}

}
