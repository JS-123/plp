package com.example.project.server;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.example.project.client.Order;
import com.example.project.client.Stock;
import com.example.project.client.User;
import com.google.gwt.user.client.Window;

public class StockTraderDAOImpl implements StockTraderDAO {

	SessionFactory factory;

	// *********TO CREATE USER*********//
	@Override
	public int createUser(User user) {
		Transaction tx = null;
		Session session = null;
		int id = 0;
		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();

			tx = session.beginTransaction();
			id = (int) session.save(user);
			tx.commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}

		return id;

	}

	// *********VALID LOGIN OR NOT*********//
	@Override
	public User isValidLogin(User user) {
		try {
			factory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(User.class);
			cr.add(Restrictions.eq("emailId", user.getEmailId()));
			List<User> allUsers = cr.list();
			user = allUsers.get(0);
			System.out.println("user");
			System.out.println(user.getPassWord());
			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();

		}
		return user;

	}

	// *********TO ADD STOCKS*********//
	@Override
	public void createStock(Stock stock) {
		Transaction tx = null;
		Session session = null;
		int stockId = 0;
		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();

			tx = session.beginTransaction();
			stockId = (int) session.save(stock);
			tx.commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}

	}

	// *********TO DELETE STOCKS*********//
	@Override
	public void deleteStock(Stock stock) {

		Transaction tx = null;
		Session session = null;
		// int stockId=0;
		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();

			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(Stock.class);
			cr.add(Restrictions.eq("stockName", stock.getStockName()));
			List<Stock> allstocks = cr.list();
			stock = allstocks.get(0);
			session.delete(stock);
			tx.commit();
		}

		catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
	}

	// *********TO LIST ALL STOCKS*********//

	@Override
	public List<Stock> fetchStocks(Stock stock) {
		List<Stock> allstocks = null;

		Transaction tx = null;
		Session session = null;
		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();

			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(Stock.class);

			cr.add(Restrictions.eq("emailId", stock.getEmailId()));

			allstocks = cr.list();

			tx.commit();
		}

		catch (Exception e) {
			e.printStackTrace();
			Window.alert("");
		} finally {
			session.close();
		}

		return allstocks;

	}

	@Override
	public void createOrder(Order order) {
		Transaction tx = null;
		Session session = null;
		int orderId = 0;
		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();

			tx = session.beginTransaction();

			// orderId=(int)session.save(order);
			session.save(order);
			tx.commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}

	}

	@Override
	public List<Order> listOrders(Order order) {
		List<Order> allorders = null;

		Transaction tx = null;
		Session session = null;
		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();

			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(Order.class);

			cr.add(Restrictions.eq("emailId", order.getEmailId()));

			allorders = cr.list();

			tx.commit();
		}

		catch (Exception e) {
			e.printStackTrace();
			Window.alert("");
		} finally {
			session.close();
		}

		
		return allorders;
	}

}

/*
 * try { factory = new
 * Configuration().configure("hibernate.cfg.xml").buildSessionFactory(); } catch
 * (Throwable ex) { System.err.println( "factory obj error : "+ex.getMessage());
 * throw new ExceptionInInitializerError(ex);
 * 
 * } Session session = factory.openSession(); Transaction tx=null;
 * 
 * try {
 * 
 * tx = session.beginTransaction(); session.save(user); tx.commit();
 * 
 * }
 * 
 * catch (Exception e) { if (tx!=null) tx.rollback(); e.printStackTrace(); }
 * 
 * finally { session.close();
 * 
 * } return id;
 * 
 * }
 * 
 * 
 * }
 */