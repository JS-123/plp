package com.example.project.server;

import java.util.List;

import com.example.project.client.Order;
import com.example.project.client.Stock;
import com.example.project.client.StockTraderService;
import com.example.project.client.User;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class StockTraderServiceImpl extends RemoteServiceServlet implements StockTraderService {

	private static final long serialVersionUID = 1L;

	private StockTraderDAO stocktraderdao;

	@Override
	public int createUser(User user) {

		stocktraderdao = new StockTraderDAOImpl();
		int id = stocktraderdao.createUser(user);
		return id;
	}

	@Override
	public User isValidLogin(User user) {
		stocktraderdao = new StockTraderDAOImpl();
		user = stocktraderdao.isValidLogin(user);
		return user;

	}

	@Override
	public void createStock(Stock stock) {
		stocktraderdao = new StockTraderDAOImpl();
		stocktraderdao.createStock(stock);

	}

	@Override
	public void deleteStock(Stock stock) {
		stocktraderdao = new StockTraderDAOImpl();
		stocktraderdao.deleteStock(stock);

	}

	@Override
	public List<Stock> fetchStocks(Stock stock) {
		stocktraderdao = new StockTraderDAOImpl();
		List<Stock> stocks = stocktraderdao.fetchStocks(stock);
		return stocks;
	}

	@Override
	public void createOrder(Order order) {

		stocktraderdao = new StockTraderDAOImpl();
		stocktraderdao.createOrder(order);

	}

	@Override
	public List<Order> listOrders(Order order) {
		stocktraderdao = new StockTraderDAOImpl();
		List<Order> orders = stocktraderdao.listOrders(order);
		return orders;
	}

}