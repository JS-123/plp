package com.example.project.server;

import java.util.List;

import com.example.project.client.Order;
import com.example.project.client.Stock;
import com.example.project.client.User;

public interface StockTraderDAO {
	
	//*****FOR CUSTOMER*****//
	
	public int createUser(User user);
	public User isValidLogin(User user);
	
	
	public void createStock(Stock stock);
	public void deleteStock(Stock stock);
	public List<Stock> fetchStocks(Stock stock);
	
	public void createOrder(Order order);
	public List<Order> listOrders(Order order);
	  
   

}