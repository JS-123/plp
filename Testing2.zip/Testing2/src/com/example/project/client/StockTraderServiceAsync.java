package com.example.project.client;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface StockTraderServiceAsync {

	void createUser(User user, AsyncCallback<Integer> callback);

	void isValidLogin(User user, AsyncCallback<User> callback);

	

	void createStock(Stock stock, AsyncCallback<Void> callback);

	void deleteStock(Stock stock, AsyncCallback<Void> callback);

	void fetchStocks(Stock stock, AsyncCallback<List<Stock>> callback);

	void createOrder(Order order, AsyncCallback<Void> callback);

	void listOrders(Order order, AsyncCallback<List<Order>> callback);

	

	

	

	

	//void isValidLogin(User user, AsyncCallback<User> callback);

	

	
	
}
