package com.example.project.client;

import java.util.List;

import com.example.project.client.User;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;


@RemoteServiceRelativePath("greet")
public interface StockTraderService extends RemoteService {
	
	//*****FOR CUSTOMER*****//
	
		public int createUser(User user);
		public User isValidLogin(User user);
	
		public void createStock(Stock stock);
      public void deleteStock(Stock stock);
        public List<Stock> fetchStocks(Stock stock);
       
         public void createOrder(Order order);
     public List<Order> listOrders(Order order);
  
}
