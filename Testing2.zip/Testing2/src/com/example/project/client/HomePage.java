package com.example.project.client;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.Root;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.Random;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.MenuBar;
import com.google.gwt.user.client.ui.MenuItem;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class HomePage {
	VerticalPanel verticalpanel ;
	HorizontalPanel hopp;
	
	OrderPage orderpage=new OrderPage();
	
	private int REFRESH_INTERVAL = 1000;

	Timer refresh;

	public static FlexTable stockTable = new FlexTable();

	int i = 0;
	TextBox t;
	private int row;
	Button remove;

	private Label updateLabel;

	public HorizontalPanel home(HorizontalPanel hpn) {

		 verticalpanel = new VerticalPanel();

		verticalpanel.setSpacing(10);
		verticalpanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		 hopp = new HorizontalPanel();

		updateLabel = new Label("Biscuitttttt");
		DateTimeFormat dates = DateTimeFormat.getFormat(DateTimeFormat.PredefinedFormat.DATE_TIME_MEDIUM);
		updateLabel.setText("Last Update:" + dates.format(new Date()));
		updateLabel.setWidth("5");

		Label lb1 = new Label("Heyy");
		hpn.add(lb1);

		MenuBar menu = new MenuBar();
		menu.setAutoOpen(true);
		menu.setWidth("500px");

		menu.setAnimationEnabled(true);

		// Create the stocks menu
		MenuBar stocksMenu = new MenuBar(true);
		stocksMenu.setAnimationEnabled(true);

		stocksMenu.addItem("MY STOCKS", new Command() {
			@Override
			public void execute() {
				showSelectedMenuItem("MY STOCKS");
			}
		});

		stocksMenu.addItem("GAINERS", new Command() {
			@Override
			public void execute() {
				showSelectedMenuItem("GAINERS");
			}
		});

		stocksMenu.addItem("LOSERS", new Command() {
			@Override
			public void execute() {
				showSelectedMenuItem("LOSERS");
			}
		});

		// Create market Menu
		MenuBar marketMenu = new MenuBar(true);
		marketMenu.setAnimationEnabled(true);

		marketMenu.addItem("TOP GAINERS", new Command() {
			@Override
			public void execute() {
				showSelectedMenuItem("TOP GAINERS");
			}
		});

		marketMenu.addItem("TOP LOSERS", new Command() {
			@Override
			public void execute() {
				showSelectedMenuItem("TOP LOSERS");
			}
		});

		marketMenu.addItem("NEWS", new Command() {
			@Override
			public void execute() {
				showSelectedMenuItem("NEWS");
			}
		});

		// menu.addItem(new MenuItem("HOME", homeMenu));
		// menu.addSeparator();
		menu.addItem(new MenuItem("MY PORTFOLIO", stocksMenu));
		menu.addSeparator();
		menu.addItem(new MenuItem("MARKET", marketMenu));

		// add the menu to the root panel
		RootPanel.get("table1").add(menu);

		hpn.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);

		stockTable.setBorderWidth(1);
		stockTable.setCellSpacing(10);
		stockTable.setCellPadding(10);

		stockTable.setText(0, 0, "Company");
		stockTable.setText(0, 1, "Price");
		stockTable.setText(0, 2, "Change");
		stockTable.setText(0, 3, "Remove");
		stockTable.setText(0, 4, "Buy");

		stockTable.setStyleName("FTable");
		stockTable.setStyleName("FTable-OddRow");
		stockTable.setStyleName("FTable-EvenRow");
		stockTable.setStyleName("FTable-ColumnLabel");
		stockTable.setStyleName("FTable-ColumnLabelCell");
		stockTable.setStyleName("FTable-Cell");

		verticalpanel.add(stockTable);

		User user = new User();

		Stock stock = new Stock();
		Window.alert(Testing2.getEmail());
		stock.setEmailId(Testing2.getEmail());

		StockTraderServiceAsync StockAsync = GWT.create(StockTraderService.class);

		StockAsync.fetchStocks(stock, new AsyncCallback<List<Stock>>() {

			@Override
			public void onSuccess(List<Stock> result) {
				
				for (int i = 0; i <= result.size(); i++) {
					stockTable.setText(i+1, 0, result.get(i).getStockName());
					stockTable.setText(i+1, 1, String.valueOf(result.get(i).getStockPrice()));
					stockTable.setText(i+1, 2, String.valueOf(result.get(i).getChange()));
					
					
					//refreshwatchList();
					PushButton remove1= new PushButton(new Image("no.png"));
					stockTable.setWidget(i+1, 3, remove1);
					
					
					
					remove1.addClickHandler(new ClickHandler() {
						
						@Override
						public void onClick(ClickEvent event) {
							
							int row = stockTable.getCellForEvent(event).getRowIndex();

							removeStock(row);

							stockTable.removeRow(row);
							
							
							
							
						
							
						}
					});
					
					PushButton order1=new PushButton(new Image("order.jpg"));
					stockTable.setWidget(i+1, 4, order1);
					order1.addClickHandler(new ClickHandler() {
						
						@Override
						public void onClick(ClickEvent event) {
							int row=stockTable.getCellForEvent(event).getRowIndex();
							createOrder(row);
							
							hopp.clear();
							verticalpanel.clear();
							stockTable.clear();
							RootPanel.get("table1").clear();
							//RootPanel.get("stockTable").clear();
							
							hopp = orderpage.order(hopp);
							RootPanel.get("table1").add(hopp);	
							
						}
				public void createOrder(int row){
					Order order=new Order();
					order.setEmailId(Testing2.getEmail());
					order.setStockName(stockTable.getText(row, 0));
					
					order.setStockPrice(Double.parseDouble(stockTable.getText(row, 1)));
					
					//order.setStockPrice(stockTable.getText(row, 1));
					order.setDateOfPurchase(new Date().toString());
					
					StockTraderServiceAsync StockAsync = GWT.create(StockTraderService.class);
					StockAsync.createOrder(order, new AsyncCallback<Void>() {
						
						@Override
						public void onSuccess(Void result) {
							Window.alert("success");
							
							
						}
						
						@Override
						public void onFailure(Throwable caught) {
							// TODO Auto-generated method stub
							
						}
					});
					
					
							
						}
					});
				}

			}

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub

			}
		});
		t = new TextBox();

		hopp.add(t);

		Button add = new Button("ADD STOCK");

		add.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				// i = stockTable.getRowCount();

				if (t.getText() == "") {
					Window.alert("Empty Creds");
					t.setFocus(true);
				} else {
					addStock();

				}

			}

		});

		hopp.add(add);

		// verticalpanel.add(updateLabel);
		verticalpanel.add(hopp);

		RootPanel.get("table1").add(stockTable);
		RootPanel.get("table1").add(verticalpanel);
		RootPanel.get("table1").add(updateLabel);

		return hpn;

	}

	protected void showSelectedMenuItem(String string) {
		// TODO Auto-generated method stub

	}

	public void isLogged(User user) {
		// TODO Auto-generated method stub

	}

	public void addStock() {

		refresh = new Timer() {
			public void run() {
				refreshwatchList();

			}
		};

		refresh.scheduleRepeating(REFRESH_INTERVAL);
		DateTimeFormat dates = DateTimeFormat.getFormat(DateTimeFormat.PredefinedFormat.DATE_TIME_MEDIUM);
		updateLabel.setText("Last Update:" + dates.format(new Date()));
		updateLabel.setWidth("5");

		int i = stockTable.getRowCount();
		// i++;
		stockTable.setText(i, 0, t.getText());

		PushButton orderbutn = new PushButton(new Image("order.jpg"));
		stockTable.setWidget(i, 4, orderbutn);
		
		orderbutn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				int row=stockTable.getCellForEvent(event).getRowIndex();
				createOrder(row);
			
				hopp.clear();
				verticalpanel.clear();
				stockTable.clear();
				RootPanel.get("table1").clear();
				//RootPanel.get("stockTable").clear();
				
				hopp = orderpage.order(hopp);
				RootPanel.get("table1").add(hopp);
				
			}
			public void createOrder(int row){
				Order order=new Order();
				order.setEmailId(Testing2.getEmail());
				order.setStockName(stockTable.getText(row, 0));
				
				order.setStockPrice(Double.parseDouble(stockTable.getText(row, 1)));
				
				//order.setStockPrice(stockTable.getText(row, 1));
				order.setDateOfPurchase(new Date().toString());
				StockTraderServiceAsync StockAsync = GWT.create(StockTraderService.class);
				StockAsync.createOrder(order, new AsyncCallback<Void>() {
					
					@Override
					public void onSuccess(Void result) {
						//Window.alert("we did it");
						
						
					}
					
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub
						
					}
				});
				
			}
		});

		

		PushButton remove = new PushButton(new Image("no.png"));

		remove.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				// int i = stockTable.getRowCount();

				int row = stockTable.getCellForEvent(event).getRowIndex();

				removeStock(row);

				stockTable.removeRow(row);
			}
		});

		stockTable.setWidget(i, 3, remove);

		Stock st = new Stock();
		st.setStockName(t.getText());
		double price = Random.nextDouble();
		double change = price * 0.02 * (Random.nextDouble() * 2.0 - 1.0);
		st.setStockPrice(price);
		st.setChange((float) change);
		st.setEmailId(Testing2.getEmail());

		StockTraderServiceAsync StockAsync = GWT.create(StockTraderService.class);
		StockAsync.createStock(st, new AsyncCallback<Void>() {

			@Override
			public void onSuccess(Void result) {

			}

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub

			}
		});
		t.setText("");
		t.setFocus(true);

	}

	private void refreshwatchList() {
		
		final double MAX_PRICE = 200.0;
		final double MAX_PRICE_CHANGE = 0.02;
		for (int j = 1; j < stockTable.getRowCount(); j++) {
			double price = Random.nextDouble() * MAX_PRICE;
			stockTable.setText(j, 1, String.valueOf(price));
			double change = price * 0.02 * (Random.nextDouble() * 2.0 - 1.0);
			stockTable.setText(j, 2, String.valueOf(change));
			DateTimeFormat dates = DateTimeFormat.getFormat(DateTimeFormat.PredefinedFormat.DATE_TIME_MEDIUM);
			updateLabel.setText("Last Update:" + dates.format(new Date()));

		}

	}

	public void removeStock(int row) {

		Stock stock = new Stock();
		// Window.alert("helloo");

		// Window.alert(stockTable.getText(row, 0));
		stock.setStockName(stockTable.getText(row, 0));
		StockTraderServiceAsync StockAsync = GWT.create(StockTraderService.class);
		StockAsync.deleteStock(stock, new AsyncCallback<Void>() {

			@Override
			public void onSuccess(Void result) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub

			}
		});

	}

}
