package com.example.project.client;

import java.io.Serializable;

import javax.validation.constraints.Size;

import com.sun.istack.internal.NotNull;


public class User implements Serializable{
    

	private static final long serialVersionUID = 1L;

	private int id;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
//	private int userId;
	
	
	private String userName;
	
	private String passWord;
	
	private String phoneNum;
	
	private String emailId;
	    
	private String city;
	
	private String DOB;
	/*public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}*/
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	/*private User(int userId, String userName, String passWord, long phoneNum, String emailId, String city, int dOB) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.passWord = passWord;
		this.phoneNum = phoneNum;
		this.emailId = emailId;
		this.city = city;
		DOB = dOB;
	}*/
	public User() {
		super();
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", passWord=" + passWord + ", phoneNum=" + phoneNum
				+ ", emailId=" + emailId + ", city=" + city + ", DOB=" + DOB + "]";
	}
    
	
	
}
