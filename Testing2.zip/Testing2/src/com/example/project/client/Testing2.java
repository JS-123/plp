package com.example.project.client;

import java.awt.Dialog;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.DateBox;


public class Testing2 implements EntryPoint {
	TextBox t1;
	PasswordTextBox t2;
	/*String userName="jayasurya";
	String passWord="Hello@123";*/
	
	private VerticalPanel vp;
	
	public static String email;
	

	public static String getEmail() {
		return email;
	}


	public static void setEmail(String email) {
		Testing2.email = email;
	}


	@Override
	public void onModuleLoad() {
		RegistrationPage register=new RegistrationPage();
		HomePage homepage=new HomePage();
		OrderPage orderpage=new OrderPage();
		
		
 
		vp = new VerticalPanel();
		
	VerticalPanel panel=new VerticalPanel();
	
	//HorizontalPanel panel1=new HorizontalPanel();
	
	//*****FOR HEADING*****//
	/*Label label2=new Label("ASSET DIRECT");
		label2.setStyleName("gwt-Css-Label");
	label2.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
	panel.add(label2);*/
	
	
	//*****FOR LOGIN*****//
			
	Label label=new Label("LOGIN");
	
	
	label.setStyleName("gwt-My-Label");
	
	label.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
	
	panel.add(label);
	
	
	
	
	//*****FOR USERNAME*****//
	Label l1=new Label("UserName");
	panel.add(l1);
	panel.setSpacing(10);
	
	 

	TextBox t1=new TextBox();
	panel.setSpacing(70);
	panel.add(t1);
	
	
	Anchor anchor=new Anchor("Forgot UserName",false,"http://www.google.co.in","_blank");
	panel.add(anchor);
	
	 
    
	
	//*****FOR PASSWORD*****//
//	HorizontalPanel hopanel=new HorizontalPanel();
	
	 Label l2=new Label("Password");
	 panel.add(l2);
	 panel.setSpacing(5);
	
	 PasswordTextBox t2= new PasswordTextBox();
	 panel.add(t2);
	 //t2.setText("****");
	 t2.setReadOnly(false);

	 Anchor anchor1=new Anchor("Forgot Password?",false,"http://www.google.co.in","_blank");
	 panel.add(anchor1);
	     
	//*****FOR DOB*****//
	 
	 Label l3 = new Label("Select Date Of Birth");
	 panel.add(l3);
	 panel.setSpacing(8);
	 
	 DateTimeFormat dateFormat = DateTimeFormat.getFormat("MM/dd/yyyy");
	 DateBox dateBox = new DateBox();
	 dateBox.setFormat(new DateBox.DefaultFormat(dateFormat));
	 panel.add(dateBox);
     RootPanel.get("table1").add(panel);
   
     //*****FOR DROPDOWN*****//
     
     Label l4=new Label("Take Me To:");
     panel.add(l4);
     panel.setSpacing(6);
          
     ListBox listbox=new ListBox();
     listbox.addItem("Trading");
     listbox.addItem("My Account");
     listbox.addItem("My Portfolio");
     listbox.addItem("Wise Advisor");
     listbox.setVisibleItemCount(1);
     panel.add(listbox);
     RootPanel.get("table1").add(panel);
     panel.setSpacing(10);
	     
	    
  //*****FOR LOGIN AND LOGIN COMMODITIES BUTTONS:*****//  
    
	 HorizontalPanel hPanel=new HorizontalPanel();
	 
	 PushButton button = new PushButton("LOGIN");
	 button.addStyleName("gwt-Blue-Button");
	 button.addClickHandler(new ClickHandler() {
	
		 public void onClick(ClickEvent event) {
  	 
				 if(t1.getText()==""|| t2.getText()=="" )
				 {
					 Window.alert("Missing Credentials");
					
						 }
				 else{
					 User user=new User();
					 user.setEmailId(t1.getText().toString());
			 StockTraderServiceAsync StockAsync=GWT.create(StockTraderService.class);
				 		
					 StockAsync.isValidLogin(user,new AsyncCallback<User>(){

						@Override
						public void onFailure(Throwable caught) {
							Window.alert("RPC FAILED");
							
							
						}

						@Override
						public void onSuccess(User user) {
						//	System.out.println("Success"+user.getPassWord());
							setEmail(user.getEmailId());
							
							String passWord=t2.getText().toString();
							
							//System.out.println("Success"+ passWord);
							
							String hello=user.getPassWord();
							System.out.println(hello);
						
							//Window.alert(hello+passWord);
							
							Window.alert("Welcome  "+user.getUserName());
							
							if(hello==passWord)
							{
								System.out.println("wrong creds!");
							//Testing2 test=new Testing2();
							//HomePage home=new HomePage();
							//test.setLogoutVisible();
							
								homepage.home(hPanel);
							
								panel.clear();
							hPanel.clear();
							vp.clear();
						
							DialogBox d=new DialogBox();
							
							d.setText("successfully logged in as "+user.getUserName());
							
							d.setAnimationEnabled(true);
							d.center();
							Button exit=new Button("close");
							exit.setPixelSize(300, 23);
							d.setWidget(exit);
							exit.addClickHandler(new ClickHandler() {
								
								@Override
								public void onClick(ClickEvent event) {
									d.hide();
									
									
								}
							});
							
							RootPanel.get("navlist").clear();
							RootPanel.get("navlist2").clear();
						
							Testing2 tests=new Testing2();
							tests.onModuleLoad();
						
						}
								
						
						else{
					 DialogBox d=new DialogBox();
						d.setText("invalid password!!");
						d.setAnimationEnabled(true);
						d.center();
						Button exit=new Button("close");
						exit.setPixelSize(300, 23);
						d.setWidget(exit);
						exit.addClickHandler(new ClickHandler() {
							
							@Override
							public void onClick(ClickEvent event) {
							d.hide();
							
								
							}
						});
						d.show();
						}
						
						}
					 });
				 }
				 
				 
	//	vp.clear();
	//	 hPanel.clear();
	//	 panel.clear();
	//	 homepage.home(hPanel);
	       }
	     });
	 hPanel.add(button);
	 RootPanel.get("table1").add(hPanel); 
	 hPanel.setSpacing(15);
	
	 
	 PushButton button1 = new PushButton("LOGIN TO COMMODITIES");
	 
	 button1.addStyleName("gwt-Green-Button");
	 
	 button1.addClickHandler(new ClickHandler() {
	 
		 public void onClick(ClickEvent event) {
	
			
			 if(t1.getText()==""|| t2.getText()=="" )
			 {
				 Window.alert("Missing Credentials");
				
			 }
			
			 else
			 {
				
				 User user=new User();
				 user.setEmailId(t1.getText().toString());
		 
				 StockTraderServiceAsync StockAsync=GWT.create(StockTraderService.class);
		 StockAsync.isValidLogin(user, new AsyncCallback<User>() {
			
			 
			 @Override
				public void onFailure(Throwable caught) {
					Window.alert("RPC FAILED AGAIN");
					
				}
			 
			@Override
			public void onSuccess(User user) {
				
				setEmail(user.getEmailId());
				
				String passWord=t2.getText().toString();
				
				
				
				String hello=user.getPassWord();
				System.out.println(hello);
			
			
				
				Window.alert("Welcome  "+user.getUserName());
				
				if(hello==passWord)
				{
					System.out.println("wrong creds!");
				
					panel.clear();
					hPanel.clear();
					vp.clear();
					
				 orderpage.order(hPanel);
				 
					RootPanel.get("table1").add(hPanel);

				
				
			
				DialogBox d=new DialogBox();
				
				d.setText("successfully logged in as "+user.getUserName());
				
				d.setAnimationEnabled(true);
				d.center();
				
				Button exit=new Button("close");
				exit.setPixelSize(300, 23);
				d.setWidget(exit);
				exit.addClickHandler(new ClickHandler() {
					
					@Override
					public void onClick(ClickEvent event) {
						d.hide();
						
						
					}
				});
				
				RootPanel.get("navlist").clear();
				RootPanel.get("navlist2").clear();
			
				Testing2 tests=new Testing2();
				tests.onModuleLoad();
			
			}
				else{
					 DialogBox d=new DialogBox();
					 
						d.setText("invalid password!!");
						d.setAnimationEnabled(true);
						d.center();
						
						Button exit=new Button("close");
						exit.setPixelSize(300, 23);
						d.setWidget(exit);
						exit.addClickHandler(new ClickHandler() {
							
							@Override
							public void onClick(ClickEvent event) {
							d.hide();
							
								
							}
						});
						d.show();
						}
				
				
				
				}
			
		});
				 
			 }
		
	         
	       }
	     });
//	 hPanel.add(button1);
	
	 
	
	 
	 hPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
	 RootPanel.get("table1").add(hPanel); 
	 hPanel.setSpacing(15);
	 hPanel.add(button1);
	 
	 //**********RESET BUTTON************//
	 PushButton buttons= new PushButton("RESET");
	 buttons.addStyleName("gwt-Green-Button");
	 buttons.addClickHandler(new ClickHandler() {
		 public void onClick(ClickEvent event) {
			 
		 }
		 });
	 hPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
	 hPanel.add(buttons);
	 RootPanel.get("table1").add(hPanel); 
	 
	 
	//**************************************************//
	  
	 
          
	 Label l6=new Label("Don't have an account yet?");
     vp.add(l6);
     
     RootPanel.get("table1").add(vp);
     vp.setSpacing(10);
	
     Button button2 = new Button("CLICK TO REGISTER");
     
     button2.addStyleName("gwt-Coral-Button");
     button2.addClickHandler(new ClickHandler() {
       public void onClick(ClickEvent event) {
         //Window.Location.assign("http://www.facebook.com");
    	   hPanel.clear();
    	   vp.clear();
    	   panel.clear();
    	   register.registered(vp);
       }
     });
     
     vp.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
     vp.add(button2);
		
	}

/*	protected void setLogoutVisible() {
		// TODO Auto-generated method stub
		
	}
	public void isLogged(User user) {
		// TODO Auto-generated method stub
		
	}
*/
}