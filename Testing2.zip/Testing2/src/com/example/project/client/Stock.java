package com.example.project.client;

import java.io.Serializable;
import java.util.Date;

public class Stock implements Serializable{
	
	private String emailId;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	private String stockName;
	private double stockPrice;
	private User userName;
	private int quantity;
	private String dateOfPurchase;
	private float change;
	private int stockId;
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	public User getUserName() {
		return userName;
	}
	public void setUserName(User userName) {
		this.userName = userName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDateOfPurchase() {
		return dateOfPurchase;
	}
	public void setDateOfPurchase(String dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}
	public float getChange() {
		return change;
	}
	public void setChange(float change) {
		this.change = change;
	}
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	
 private Stock(String emailId, String stockName, double stockPrice, User userName, int quantity,
			String dateOfPurchase, float change, int stockId) {
		super();
		this.emailId = emailId;
		this.stockName = stockName;
		this.stockPrice = stockPrice;
		this.userName = userName;
		this.quantity = quantity;
		this.dateOfPurchase = dateOfPurchase;
		this.change = change;
		this.stockId = stockId;
	}
public Stock() {
		super();
	}
@Override
public String toString() {
	return "Stock [emailId=" + emailId + ", stockName=" + stockName + ", stockPrice=" + stockPrice + ", userName="
			+ userName + ", quantity=" + quantity + ", dateOfPurchase=" + dateOfPurchase + ", change=" + change
			+ ", stockId=" + stockId + "]";
}
	
}