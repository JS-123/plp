package com.example.project.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.DateBox;

public class RegistrationPage {
	
	
	
	public VerticalPanel registered(VerticalPanel vpanel){
		
		
	
		
		Label label=new Label("This is a one time registration process!!");
		
		label.setStyleName("gwt-second-Label");
		
	//	label.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		
		vpanel.add(label);
		
		
		//*****NAME*****//
		
		Label lb=new Label("Name:");//NAME
	
		vpanel.add(lb);
		
		TextBox box=new TextBox();  //TEXTBOX
	
		vpanel.add(box);
		
		//HorizontalPanel hpl=new HorizontalPanel();
	
		Label lb2=new Label("Email ID");
		vpanel.add(lb2);
		
		TextBox box2=new TextBox();
		vpanel.add(box2);
		
		Label lb3=new Label("Mobile No:");
		vpanel.add(lb3);
		
		TextBox box3=new TextBox();
		vpanel.add(box3);
		
		Label l2=new Label("Set Password");
		 vpanel.add(l2);
		 
		 PasswordTextBox t2= new PasswordTextBox();
		 vpanel.add(t2);
		 
		 Label l3=new Label("Confirm Password");
		 vpanel.add(l3);
		 
		 PasswordTextBox t3= new PasswordTextBox();
		 vpanel.add(t3);
		 
		
		
		Label lb4=new Label("City:");
		vpanel.add(lb4);
	
		ListBox listbox=new ListBox();
	     listbox.addItem("Hyderabad");
	     listbox.addItem("Delhi");
	     listbox.addItem("Vijayawada");
	     listbox.addItem("Mumbai");
	     listbox.addItem("Bangalore");
	     listbox.addItem("Pune");
	     listbox.addItem("Jaipur");
	     listbox.addItem("Chandigarh");
	     listbox.addItem("Trivandrum");
	     listbox.setVisibleItemCount(1);
	     vpanel.add(listbox);
	     vpanel.setSpacing(30);
	     
	     Label l31 = new Label("Select Date Of Birth");
		 vpanel.add(l31);
		vpanel.setSpacing(16);
		 
		 DateTimeFormat dateFormat = DateTimeFormat.getFormat("MM/dd/yyyy");
		 DateBox dateBox = new DateBox();
		 dateBox.setFormat(new DateBox.DefaultFormat(dateFormat));
		 vpanel.add(dateBox);
	   //  RootPanel.get("table1").add(vpanel);
	     
	     PushButton button = new PushButton("REGISTER");
		 button.addStyleName("gwt-Black-Button");
		 button.addClickHandler(new ClickHandler() {
		
			 public void onClick(ClickEvent event) {
			
				 User user=new User();
				 
				 user.setUserName(box.getText().toString());
				 user.setEmailId(box2.getText().toString());
				 user.setPhoneNum(box3.getValue().toString());
				 user.setPassWord(t2.getText().toString());
				 user.setPassWord(t3.getText().toString());
				 user.setCity(listbox.getSelectedItemText().toString());
				 user.setDOB(dateBox.getValue().toString());
				 StockTraderServiceAsync StockAsync=GWT.create(StockTraderService.class);
				 		
				 StockAsync.createUser(user,new AsyncCallback<Integer>(){

					@Override
					public void onFailure(Throwable caught) {
						System.out.println("error");
						
					}

					@Override
					public void onSuccess(Integer result) {
						// TODO Auto-generated method stub
						Testing2 test=new Testing2();
						test.onModuleLoad();
						//panel.clear();
						vpanel.clear();
						System.out.println("success");
					}
					 

					
					 
				 });
				 
		    
			 }
		     });
		 
		 vpanel.add(button);
		
		
		return vpanel;
		
		
		
		
		
	}

}
