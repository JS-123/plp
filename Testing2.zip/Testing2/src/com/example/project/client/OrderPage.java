package com.example.project.client;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class OrderPage {
	FlexTable flex;
	
public HorizontalPanel order(HorizontalPanel hPan){
	Window.alert("ordersssssssssssssssssss");
	VerticalPanel vpan=new VerticalPanel();
	
			/*Label lb=new Label("heyyy");
			hPan.add(lb);*/
			
			flex=new FlexTable();
			flex.setBorderWidth(1);
			flex.setCellSpacing(10);
			flex.setCellPadding(10);
			
			flex.setText(0, 0, "Serial Number");
			flex.setText(0, 1, "Company");
			flex.setText(0, 2, "Price");
			flex.setText(0, 3, "DateOfPurchase");
			
		//	flex.setText(0, 2, "Change");
			//flex.setText(0, 3, "Remove");
			//flex.setText(0, 4, "Buy");
			
			hPan.add(flex);
			
			
			
		User user=new User();
Order order = new Order();		Window.alert(Testing2.getEmail());
		order.setEmailId(Testing2.getEmail());
		StockTraderServiceAsync StockAsync = GWT.create(StockTraderService.class);
		StockAsync.listOrders(order, new AsyncCallback<List<Order>>() {
			
			@Override
			public void onSuccess(List<Order> result) {
				//Window.alert("HII");
				//Window.alert(result.toString());
				
				//flex.setText(0, 1, result.toString());
				for(int i = 0; i <= result.size(); i++){
					flex.setText(i+1, 0, String.valueOf(result.get(i).getOrderId()));
					flex.setText(i+1, 1, result.get(i).getStockName());
					flex.setText(i+1, 2, String.valueOf(result.get(i).getStockPrice()));
					flex.setText(i+1, 3, result.get(i).getDateOfPurchase());
					//flex.setText(i+1, 2, String.valueOf(result.get(i).getChange()));
					
				}
				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}
		});
		

			
			
			
	RootPanel.get("table1").add(hPan);
	
	return hPan;
	
}
}
