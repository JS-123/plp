package com.example.project.client;

import java.io.Serializable;

public class Order implements Serializable{
	private String stockName;
	private double stockPrice;
	private int orderId;
	private String dateOfPurchase;
	private String emailId;
	
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getDateOfPurchase() {
		return dateOfPurchase;
	}
	public void setDateOfPurchase(String dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "Order [stockName=" + stockName + ", stockPrice=" + stockPrice + ", orderId=" + orderId
				+ ", dateOfPurchase=" + dateOfPurchase + ", emailId=" + emailId + "]";
	}
	public Order(String stockName, double stockPrice, int orderId, String dateOfPurchase, String emailId) {
		super();
		this.stockName = stockName;
		this.stockPrice = stockPrice;
		this.orderId = orderId;
		this.dateOfPurchase = dateOfPurchase;
		this.emailId = emailId;
	}
	public Order() {
		super();
	}
	
	
	
	
	

}
