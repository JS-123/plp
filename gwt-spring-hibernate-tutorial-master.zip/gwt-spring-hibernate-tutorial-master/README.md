gwt-spring-hibernate-tutorial
=============================

An Example how to use GWT, Spring and Hibernate together.