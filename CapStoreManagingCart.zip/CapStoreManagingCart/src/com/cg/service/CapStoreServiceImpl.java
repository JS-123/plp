package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.dao.ICapStoreDao;
import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
@Service
@Transactional
public class CapStoreServiceImpl implements ICapStoreService {

	@Autowired
	ICapStoreDao iCapStoreDao;
	
	@Override
	public boolean add(int customerId) {
		// TODO Auto-generated method stub
		return iCapStoreDao.add(customerId); 
	}

	@Override
	public void remove(int inventoryId) {
		
		iCapStoreDao.remove(inventoryId);
	}

	@Override
	public void tableCreation() {
		iCapStoreDao.tableCreation();
		
	}

	@Override
	public List<Inventory> fetchCart() {
		
		return iCapStoreDao.fetchCart();
	}

	@Override
	public boolean checkAvailability(int customerId,String quantity[]) {
		
		return iCapStoreDao.checkAvailability(customerId,quantity);
	}

	@Override
	public int totalAmount(int customerId) {
		
		return iCapStoreDao.totalAmount(customerId);
	}

	@Override
	public int totalDiscount(int customerId) {
		
		return iCapStoreDao.totalDiscount(customerId);
	}

	@Override
	public List<String> getCoupons(int customerId) {
		// TODO Auto-generated method stub
		return iCapStoreDao.getCoupons(customerId);
	}

	@Override
	public Double getCouponDiscount(String couponId) {
		// TODO Auto-generated method stub
		return iCapStoreDao.getCouponDiscount(couponId);
	}

}
