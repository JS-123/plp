package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.service.ICapStoreService;


@Controller
public class ControllerClass {

	@Autowired
	ICapStoreService iCapStoreService;
	
	@PersistenceContext
	EntityManager entityManager;
	
	List<String> quantity;
	
	
	@RequestMapping("/index")
	public String page()
	{
		iCapStoreService.tableCreation();
		return "index";
	}
	
	
	@RequestMapping("/addToCart")
	public String add(Model model)
	{
		int customerId=0;
		quantity=new ArrayList<String>();
		quantity.add("1");
		quantity.add("2");
		quantity.add("3");
		List<Inventory> list=iCapStoreService.fetchCart();
		/*boolean add=iCapStoreService.add(customerId);
		if(add)
		{*/
			model.addAttribute("quantity",quantity);
			model.addAttribute("cartList",list);
			return "cart";
		/*}
		else
		{
			model.addAttribute("quantity",quantity);
			model.addAttribute("cartList",list);
			return "cart";
		}*/
		
		
	}
	
	@RequestMapping("/removeFromCart")
	public String remove(Model model,@RequestParam("name")String inventoryId)
	{
		iCapStoreService.remove(Integer.parseInt(inventoryId));
		//List<Inventory> list=iCapStoreService.fetchCart();
		//model.addAttribute("cartList",list);
		return "redirect:displayInCart.html";
	}
	
	@RequestMapping("/displayInCart")
	public String display(Model model)
	{
		int customerId=6;
		List<Inventory> list=iCapStoreService.fetchCart();
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount);
		return "cart";
	}
	
	/*@RequestMapping("/validate")
	public String checkAvailability(HttpServletRequest request)
	{
		//int customerId=0;
		//boolean check=iCapStoreService.checkAvailability(customerId);
		//if(check)
		

		 String a[]= request.getParameterValues("quantity"); 
		// System.out.println(a.length);
			return "success";
		//else
			//return "cart";
			
			// String a[]= request.getParameterValues("quantity"); 
				
	}*/

	/*@RequestMapping(value="/validate")
	public String getInvoice(Model model)
	{
		int customerId=3;
		List<Inventory> list=iCapStoreService.fetchCart();
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount);
		
		return "invoice";
		
	}*/
	@RequestMapping(value="/validate")
	public String getInvoice(Model model)
	{
		int customerId=6;
		List<Inventory> list=iCapStoreService.fetchCart();
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount);
		List<String> couponsNumber=iCapStoreService.getCoupons(customerId);
		model.addAttribute("coupons",couponsNumber);
		return "cart";
		
	}
	
	@RequestMapping("/applyCoupons")
	public String applyCoupons(Model model,@RequestParam("couponId")String couponId) {
		int customerId=6;
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		List<Inventory> list=iCapStoreService.fetchCart();
		Double couponAmount=iCapStoreService.getCouponDiscount(couponId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount-couponAmount);
		List<String> couponsNumber=iCapStoreService.getCoupons(customerId);
		return null;
	}
}
