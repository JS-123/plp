package com.cg.dao;

import java.util.List;

import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;

public interface ICapStoreDao {

	boolean add(int customerId);

	public void remove(int inventoryId);

	public void tableCreation();

	public List<Inventory> fetchCart();

	boolean checkAvailability(int customerId,String quantity[]);

	public int totalAmount(int customerId);

	public int totalDiscount(int customerId);

	List<String> getCoupons(int customerId);

	Double getCouponDiscount(String couponId);

	
}
