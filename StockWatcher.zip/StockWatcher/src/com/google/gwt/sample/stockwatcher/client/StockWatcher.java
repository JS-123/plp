package com.google.gwt.sample.stockwatcher.client;

import com.google.gwt.sample.stockwatcher.shared.FieldVerifier;

import java.util.ArrayList;
import java.util.Date;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.user.client.Random;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HTMLTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class StockWatcher implements EntryPoint {
	   private static VerticalPanel mainpanel=new VerticalPanel();
	private FlexTable stocksFlexTable = new FlexTable();
	private HorizontalPanel addPanel = new HorizontalPanel();
	private Button buyButton=new Button("Buy");
	private Button sellButton=new Button("Sell");
	   private Button orderButton = new Button("Order");
	   private Button backButton=new Button("Back");
	private VerticalPanel mainPanel = new VerticalPanel();
	private TextBox userInputField = new TextBox();
	private Button addButton = new Button("ADD");
	private Label lastUpdatedLabel = new Label();
	 private static VerticalPanel loginpanel=new VerticalPanel();
	private ArrayList<String> stocks =  new ArrayList<String>();
	private StockPriceServiceAsync stockPriceSvc = GWT.create(StockPriceService.class);
		 
	public void onModuleLoad() {
		
		
		
		
		stocksFlexTable.setText(0,0,"symbol");
	    stocksFlexTable.setText(0,1,"price");
		stocksFlexTable.setText(0,2,"change");
		stocksFlexTable.setText(0,3,"remove");
		
		stocksFlexTable.getRowFormatter().addStyleName(0, "watchListHeader");
		stocksFlexTable.addStyleName("watchlist");
		stocksFlexTable.getCellFormatter().addStyleName(0, 1, "watchListNumericColumn");
		stocksFlexTable.getCellFormatter().addStyleName(0, 2, "watchListNumericColumn");
		stocksFlexTable.getCellFormatter().addStyleName(0, 3, "watchListRemoveColumn");
		
		addPanel.add(userInputField);
		addPanel.add(addButton);
		addPanel.addStyleName("addPanel");
		
		mainPanel.add(stocksFlexTable);
		mainPanel.add(addPanel);
		mainPanel.add(lastUpdatedLabel);
		
		RootPanel.get("stockList").add(mainPanel);
		userInputField.setFocus(true);
		
		Timer refreshTimer =  new Timer(){

			@Override
			public void run() {
				refreshWatchList();
				}
			};
		refreshTimer.scheduleRepeating(5000);
	
	addButton.addClickHandler(new ClickHandler(){
         @Override
		public void onClick(ClickEvent event) {
			addStock();
			}
		}
	);
	userInputField.addKeyDownHandler(new KeyDownHandler() {
	@Override
		public void onKeyDown(KeyDownEvent event) {
		 if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {	
		addStock();
		 }
			}
      });
	
	}

	 protected void refreshWatchList() {
		 if (stockPriceSvc == null) {
			    stockPriceSvc = GWT.create(StockPriceService.class);
			  }

			  AsyncCallback<StockPrice[]> callback = new AsyncCallback<StockPrice[]>() {
			    public void onFailure(Throwable caught) {
			     
			    }

			    public void onSuccess(StockPrice[] result) {
			      updateTable(result);
			    }
			  };
			  
			  stockPriceSvc.getPrices(stocks.toArray(new String[0]), callback);
			
	}

	private void updateTable(StockPrice[] prices) {
		// TODO Auto-generated method stub
		for (int i = 0; i < prices.length; i++) {
	        updateTable(prices[i]);
	      }
	lastUpdatedLabel.setText("LastUpdate: " +new Date());
	}

	private void updateTable(StockPrice price) {
		
		 if (!stocks.contains(price.getSymbol())) {
		       return;
		     }

		     int row = stocks.indexOf(price.getSymbol()) + 1;

		     String priceText = NumberFormat.getFormat("#,##0.00").format(
		         price.getPrice());
		     NumberFormat changeFormat = NumberFormat.getFormat("+#,##0.00;-#,##0.00");
		     String changeText = changeFormat.format(price.getChange());
		     String changePercentText = changeFormat.format(price.getpercentChange());

		    
		     stocksFlexTable.setText(row, 1, priceText);
		     stocksFlexTable.setText(row, 2, changeText + " (" + changePercentText
		         + "%)");
	}
	
	public static void clear(){
		 loginpanel.clear();
	 }
	

	private void addStock() {
	      final String symbol =userInputField.getText().toUpperCase().trim();
	     
	      userInputField.setFocus(true);
	      
	     if (!symbol.matches("^[0-9A-Z\\.]{1,10}$")) {
	    	  
	        Window.alert("'" + symbol + "' is not a valid symbol.");
	        userInputField.selectAll();
	        return;
	      }
          userInputField.setText("");
          
          if(stocks.contains(symbol)){
        	return;  
          }
          
          int row = stocksFlexTable.getRowCount();
          stocks.add(symbol);
          stocksFlexTable.setText(row,0,symbol);
          
          Button removeButton  =  new Button("X");
          removeButton.addClickHandler(new ClickHandler(){

			public void onClick(ClickEvent event) {
				int removedIndex = stocks.indexOf(symbol);
		        stocks.remove(removedIndex);
		        stocksFlexTable.removeRow(removedIndex + 1);
				
				}
        	   });
          stocksFlexTable.setWidget(row, 3, removeButton);
          refreshWatchList();
          
	}
	
	public void login()
	 {
	    TextBox tx1=new TextBox();
	    PasswordTextBox tx2=new PasswordTextBox();
	   
	    Button b = new Button("submit");
	    tx1.setName("username");
	    tx2.setName("password");
	    Label lb1=new Label("UserName");
	    Label lb2=new Label("PassWord");
	    
	    HorizontalPanel hPanel = new HorizontalPanel();	
	    HorizontalPanel hPanel1 = new HorizontalPanel();
	      hPanel.add(lb1);
	      hPanel.add(tx1);
	     
	      hPanel1.add(lb2);
	      hPanel1.add(tx2);
	      
	      
	      loginpanel.add(hPanel);
	      loginpanel.setSpacing(10);
	      loginpanel.add(hPanel1);
	    
	    
	    loginpanel.add(b);
	    b.addClickHandler(new ClickHandler() {
	 		
	 		@Override
	 		public void onClick(ClickEvent event) {
	 			
	 			//clear();
	 			//buildHome();
	 		}
	 	});
	    

	 }
	
	 };