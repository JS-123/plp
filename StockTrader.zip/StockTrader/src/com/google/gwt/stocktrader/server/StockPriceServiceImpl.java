package com.google.gwt.stocktrader.server;

import java.util.List;
import java.util.Random;

import com.google.gwt.stocktrader.client.StockPrice;
import com.google.gwt.stocktrader.client.StockPriceService;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;


public class StockPriceServiceImpl extends RemoteServiceServlet implements StockPriceService {
	
	StockPriceDao stockdao=null;
	

	   public StockPriceServiceImpl(StockPriceDao stockdao) {
			this.stockdao = stockdao;
		}


		public StockPriceDao getStockdao() {
			return stockdao;
		}


		public void setStockdao(StockPriceDao stockdao) {
			this.stockdao = stockdao;
		}

		private static final double MAX_PRICE=100.0;
		private static final double MAX_PRICE_CHANGE=0.02;
		
		
		@Override
		public StockPrice[] getPrices(String[] symbols) {
	            
			Random rnd=new Random();
			 StockPrice[] prices = new StockPrice[symbols.length];
			    for (int i=0; i<symbols.length; i++) {
			      double price = rnd.nextDouble() * MAX_PRICE;
			      double change = price * MAX_PRICE_CHANGE * (rnd.nextDouble() * 2f - 1f);

			      prices[i] = new StockPrice(symbols[i], price, change);
			    }		
			
			return prices;
		}


		@Override
		public List<StockPrice> getAllStocks() {

			return stockdao.getAllStocks();
		}


		
	public StockPrice[] Save(StockPrice stock){
		System.out.println(stock);
		StockPrice[] stocks =null;
			StockPriceBo bo=new StockPriceBo();
			bo.setSymbol(stock.getSymbol());
			bo.setPrice(stock.getPrice());
			bo.setChange(stock.getChange());
			System.out.println("the bo values are"+bo);
		//stockdao = new StockPriceDaoImpl();
			
			if(stockdao!=null){
			stocks = stockdao.Save(bo);}
			return stocks;
		}

		@Override
		public void delete(StockPrice stock) {
		  stockdao.delete(stock);	
		}



}
