package com.google.gwt.stocktrader.server;

import java.util.List;

import com.google.gwt.stocktrader.client.StockPrice;

public interface StockPriceDao {
	List<StockPrice> getAllStocks();
	StockPrice[] Save(StockPriceBo bo);
	void delete(StockPrice stock);
	}
