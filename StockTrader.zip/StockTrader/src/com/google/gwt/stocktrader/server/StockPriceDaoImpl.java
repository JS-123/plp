package com.google.gwt.stocktrader.server;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.google.gwt.stocktrader.client.StockPrice;


public class StockPriceDaoImpl implements StockPriceDao{
	private HibernateTemplate hibernateTemplate;
	
	public HibernateTemplate getHibernateTemplate() {
	return hibernateTemplate;
}

public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
	this.hibernateTemplate = hibernateTemplate;
}


	public StockPriceDaoImpl(HibernateTemplate hibernateTemplate) {
	this.hibernateTemplate = hibernateTemplate;
}

	@Override
	public List<StockPrice> getAllStocks() {
		List<StockPrice> list  = hibernateTemplate.loadAll(StockPrice.class);
		return null;
	}

	@Override

	public StockPrice[] Save(StockPriceBo bo){
			return (StockPrice[]) hibernateTemplate.save(bo);
	}

	@Override
	public void delete(StockPrice stock) {
		// TODO Auto-generated method stub
		hibernateTemplate.delete(stock);
	}

}
