package com.google.gwt.stocktrader.client;

import java.util.ArrayList;
import java.util.Date;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.user.client.Random;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class StockTrader implements EntryPoint {

	private static final int REFRESH_INTERVAL = 5000;
	private static VerticalPanel mainpanel = new VerticalPanel();
	private FlexTable flex = new FlexTable();
	private HorizontalPanel hpanel = new HorizontalPanel();
	private TextBox textBox = new TextBox();
	private Button addButton = new Button("Add");
	private Button buyButton = new Button("Buy");
	private Button sellButton = new Button("Sell");
	private Button orderButton = new Button("Order");
	private Button backButton = new Button("Back");
	private Label lastUpdatedLabel = new Label();
	private ArrayList<String> stocks = new ArrayList<String>();
	private static VerticalPanel loginpanel = new VerticalPanel();

	private StockPriceServiceAsync stockPriceSvc = null;

	public void onModuleLoad() {

		login();

		mainpanel.add(loginpanel);

		// associating with html page from mainpanel
		RootPanel.get("Stocklist").add(mainpanel);
	}

	private void addStock() {
		final String symbol = textBox.getText().toUpperCase().trim();
		textBox.setFocus(true);
		if (!symbol.matches("^[0-9A-Z\\.]{1,10}$")) {
			Window.alert(symbol + "is not avalid symbol");
			textBox.selectAll();
			return;
		}
		textBox.setText(" ");

		int row;
		if (stocks.contains(symbol))
			return;
		else {
			row = flex.getRowCount();
			stocks.add(symbol);

			flex.setText(row, 0, symbol);
		}

		Button delButton = new Button("delete");
		delButton.addStyleDependentName("remove");
		delButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				int removeIndex = stocks.indexOf(symbol);
				stocks.remove(removeIndex);
				flex.removeRow(removeIndex + 1);

			}
		});

		flex.setWidget(row, 3, delButton);
		// to get stock price
		refreshWatchList();

		// Add the stock to the table.
		row = flex.getRowCount();
		stocks.add(symbol);
		// flex.setText(row, 0, symbol);
		flex.setWidget(row, 2, new Label());
		flex.getCellFormatter().addStyleName(row, 1, "watchListNumericColumn");
		flex.getCellFormatter().addStyleName(row, 2, "watchListNumericColumn");
		flex.getCellFormatter().addStyleName(row, 3, "watchListRemoveColumn");
	}

	private void refreshWatchList() {

		final double MAX_PRICE = 100.0;
		final double MAX_PRICE_CHANGE = 0.02;
		StockPrice[] prices = new StockPrice[stocks.size()];
		for (int i = 0; i < stocks.size(); i++) {
			double price = Random.nextDouble() * MAX_PRICE;
			double change = price * MAX_PRICE_CHANGE * (Random.nextDouble() * 2.0 - 1.0);
			prices[i] = new StockPrice(stocks.get(i), price, change);

		}

		// Initialize the service proxy.
		if (stockPriceSvc == null) {
			stockPriceSvc = GWT.create(StockPriceService.class);
			// ((ServiceDefTarget)
			// stockPriceSvc).setServiceEntryPoint("/Stock/stocks/stockPrice");
			ServiceDefTarget serviceDef = (ServiceDefTarget) stockPriceSvc;
			serviceDef.setServiceEntryPoint(GWT.getModuleBaseURL() + "rpc/stockPrice");
			}

		// Set up the callback object.
		AsyncCallback<StockPrice[]> callback = new AsyncCallback<StockPrice[]>() {
			public void onFailure(Throwable caught) {
				System.out.println("failure");
			}

			public void onSuccess(StockPrice[] result) {
				updateTable(result);

			}
		};

		// Make the call to the stock price service.

		// updateTable(prices);
		// stockPriceSvc.getAllStocks(callback);
		// }

		stockPriceSvc.getPrices(stocks.toArray(new String[0]), callback);
		updateTable(prices);
	}

	private void updateTable(StockPrice price) {

		if (!stocks.contains(price.getSymbol())) {
			return;
		}

		int row = stocks.indexOf(price.getSymbol()) + 1;

		String changeStyleName = "noChange";

		if (price.getChange() < -0.1f) {
			changeStyleName = "negativeChange";
		} else if (price.getChange() > 0.1f) {
			changeStyleName = "positiveChange";
		}

		// Format the data in the Price and Change fields.
		String priceText = NumberFormat.getFormat("#,##0.00").format(price.getPrice());
		NumberFormat changeFormat = NumberFormat.getFormat("+#,##0.00;-#,##0.00");
		String changeText = changeFormat.format(price.getChange());
		String changePercentText = changeFormat.format(price.getChange());
		Label Pricelbl = new Label(priceText);
		Pricelbl.setStyleName(changeStyleName);
		Label Changelbl = new Label(changeText + " (" + changePercentText + "%)");
		Changelbl.setStyleName(changeStyleName);

		flex.setWidget(row, 1, Pricelbl);
		flex.setWidget(row, 2, Changelbl);

		save(price);
	}

	// call back object
	private void save(StockPrice price) {
		// stockPriceSvc.Save(price, new AsyncCallback<StockPrice[]>() {
		stockPriceSvc.Save(price, new AsyncCallback<StockPrice[]>() {
			@Override
			public void onFailure(Throwable caught) {
				System.out.println("failure");
			}

			@Override
			public void onSuccess(StockPrice[] result) {
				System.out.println("success");
			}

		});

	}

	private void updateTable(StockPrice[] prices) {
		for (int i = 0; i < prices.length; i++) {
			updateTable(prices[i]);
		}

		DateTimeFormat dateFormat = DateTimeFormat.getFormat(DateTimeFormat.PredefinedFormat.DATE_TIME_MEDIUM);
		lastUpdatedLabel.setText("Last update : " + dateFormat.format(new Date()));
	}

	public static void clear() {
		loginpanel.clear();
	}

	public static void clean() {
		mainpanel.clear();
	}

	public void buildHome() {

		flex.setText(0, 0, "symbol");
		flex.setText(0, 1, "price");
		flex.setText(0, 2, "change");
		flex.setText(0, 3, "remove");
		flex.setCellPadding(6);

		// Add styles to elements in the stock list table.
		flex.getRowFormatter().addStyleName(0, "watchListHeader");
		flex.addStyleName("watchList");
		flex.getCellFormatter().addStyleName(0, 1, "watchListNumericColumn");
		flex.getCellFormatter().addStyleName(0, 2, "watchListNumericColumn");
		flex.getCellFormatter().addStyleName(0, 3, "watchListRemoveColumn");

		// adding button and textbox to stockpanel
		hpanel.add(textBox);
		hpanel.add(addButton);
		hpanel.add(orderButton);
		textBox.setFocus(true);

		addButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				addStock();

			}
		});
		orderButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				// clean();
				// buildOrder();
			}
		});

		hpanel.add(textBox);
		hpanel.add(addButton);

		hpanel.setSpacing(10);
		hpanel.add(orderButton);
		hpanel.addStyleName("hpanel");

		mainpanel.add(flex);
		mainpanel.add(hpanel);
		mainpanel.add(lastUpdatedLabel);
		RootPanel.get("Stocklist").add(mainpanel);

	}

	public void buildOrder() {
		// FlexTable flex1=new FlexTable();
		HorizontalPanel hpanel1 = new HorizontalPanel();
		flex.setText(0, 0, "symbol");
		flex.setText(0, 1, "price");
		flex.setText(0, 2, "remove");
		flex.setCellPadding(6);
		flex.getRowFormatter().addStyleName(0, "watchListHeader");
		flex.addStyleName("watchList");
		flex.getCellFormatter().addStyleName(0, 1, "watchListNumericColumn");

		flex.getCellFormatter().addStyleName(0, 2, "watchListRemoveColumn");
		hpanel1.add(buyButton);
		hpanel1.setSpacing(10);
		hpanel1.add(sellButton);
		hpanel1.setSpacing(10);
		hpanel1.add(backButton);
		mainpanel.add(flex);
		mainpanel.add(hpanel1);
		RootPanel.get("Stocklist").add(mainpanel);
		backButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				buildHome();
			}
		});

	}

	public void login() {
		TextBox tx1 = new TextBox();
		PasswordTextBox tx2 = new PasswordTextBox();

		Button b = new Button("submit");
		tx1.setName("username");
		tx2.setName("password");
		Label lb1 = new Label("UserName");
		Label lb2 = new Label("PassWord");

		HorizontalPanel hPanel = new HorizontalPanel();
		HorizontalPanel hPanel1 = new HorizontalPanel();
		hPanel.add(lb1);
		hPanel.add(tx1);

		hPanel1.add(lb2);
		hPanel1.add(tx2);

		loginpanel.add(hPanel);
		loginpanel.setSpacing(10);
		loginpanel.add(hPanel1);

		loginpanel.add(b);
		b.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				clear();
				buildHome();
			}
		});

	}
}