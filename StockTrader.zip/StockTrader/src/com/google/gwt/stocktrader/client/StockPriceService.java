package com.google.gwt.stocktrader.client;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
@RemoteServiceRelativePath("rpc/stockPrice")
public interface StockPriceService extends RemoteService {
	StockPrice[] getPrices(String[] symbols);
	List<StockPrice> getAllStocks();
	StockPrice[] Save(StockPrice stock);
	void delete(StockPrice stock);

}
